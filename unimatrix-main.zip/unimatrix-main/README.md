# unimatrix
UniMatrix is a PHP MLM script to build a membership site using the Unilevel plan or Forced Matrix plan with a re-entry option. The script comes with essential features to run a successful referral marketing program, including membership with renewal on an interval basis.

People can register for free and have an option to join your marketing plan from their Member CP. Unilevel and Forced Matrix plan are supported by the script, and you can configure the Unilevel plan with unlimited levels wide and up to 20 levels deep or the Forced Matrix plan with up to 10 levels wide and 20 levels deep.
